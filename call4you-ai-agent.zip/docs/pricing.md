# Call4You Pricing Plans

## Starter – $399/month
- 500 minutes (~166 calls)
- 24/7 AI agent
- Voice interactions
- Multi-language
- CRM integration

## Growth – $699/month ⭐ Most Popular
- 1,000 minutes (~333 calls)
- Everything in Starter
- 2x call volume
- Priority support
- Advanced analytics

## Pro – $1,199/month
- 2,000 minutes (~666 calls)
- Everything in Growth
- 4x call volume
- Account manager
- Custom integrations

## Custom Setup – $4,000 one-time
- Your own account + usage pricing
- Complete setup
- Pay per usage
- Full ownership
- Direct API access
